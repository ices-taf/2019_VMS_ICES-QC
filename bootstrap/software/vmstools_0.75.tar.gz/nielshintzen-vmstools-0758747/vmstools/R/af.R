`af` <-
function(x){return(as.factor(x))}

#hello world
