euharbours <- local({
cat("--------------------------------------------------------------------------------
* This harbour list does cover many harbours in Europe, but for sure is NOT
  a complete list. Please make sure the harbours of importance to you are added.

* It is also suggested to contact the maintainer of this package to include your
  harbours.

* The harbour dataset is loaded as 'harbours'

--------------------------------------------------------------------------------
")
data(harbours)
})
